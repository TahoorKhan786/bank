export class Product{
    id:number;
    name:string;
    desc:string;
    category:string;
    actualPrice:number;
    discount:number;
    price:number;
    avail:string;
    imagepath:string;
}